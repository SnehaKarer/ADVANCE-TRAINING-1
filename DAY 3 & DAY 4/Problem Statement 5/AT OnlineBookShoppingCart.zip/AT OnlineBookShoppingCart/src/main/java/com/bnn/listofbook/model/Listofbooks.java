package com.bnn.listofbook.model;

import java.io.Serializable;

public class Listofbooks implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int Bookid;
	private String Book_Name;
	private String Auther;
	private int Price;
	public int getBookid() {
		return Bookid;
	}
	public void setBookid(int bookid) {
		Bookid = bookid;
	}
	public String getBook_Name() {
		return Book_Name;
	}
	public void setBook_Name(String book_Name) {
		Book_Name = book_Name;
	}
	public String getAuther() {
		return Auther;
	}
	public void setAuther(String auther) {
		Auther = auther;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	
}
